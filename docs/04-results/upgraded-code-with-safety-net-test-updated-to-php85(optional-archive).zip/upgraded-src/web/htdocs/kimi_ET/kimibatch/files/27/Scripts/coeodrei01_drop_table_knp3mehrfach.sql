drop table knpdreimehrfach
