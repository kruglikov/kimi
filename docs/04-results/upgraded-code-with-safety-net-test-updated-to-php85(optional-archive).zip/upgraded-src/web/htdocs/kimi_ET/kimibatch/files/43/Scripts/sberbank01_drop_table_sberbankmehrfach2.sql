drop table sberbankmehrfach2
