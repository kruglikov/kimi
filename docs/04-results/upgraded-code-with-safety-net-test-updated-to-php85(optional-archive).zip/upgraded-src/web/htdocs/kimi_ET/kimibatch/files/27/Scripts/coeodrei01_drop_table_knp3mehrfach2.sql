drop table knpdreimehrfach2
