drop table sberbankmehrfach
