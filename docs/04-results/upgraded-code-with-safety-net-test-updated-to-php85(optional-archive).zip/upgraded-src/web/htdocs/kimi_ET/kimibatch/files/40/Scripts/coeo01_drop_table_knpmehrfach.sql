drop table knpmehrfach
