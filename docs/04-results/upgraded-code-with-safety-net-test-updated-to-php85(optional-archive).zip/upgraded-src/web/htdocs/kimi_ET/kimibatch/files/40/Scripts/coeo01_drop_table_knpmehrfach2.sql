drop table knpmehrfach2
