<?php

$exists = FALSE;
$schadensfall_id = param("schadensfall", NULL);
$kunde_id = param("kunde");
$kunde_nr = param("kundennummer");
$cur_id = param("cur_id", NULL);
$mode = param("mode", "SEL");
$site = param("s", 0);
$site_count = CONF_PORTAL_LINE_PER_SITE;
$show_new = param("showNew", FALSE);
$show_modify = param("showModify", FALSE);
$show_delete = param("showDelete", FALSE);
$modify_id = param("modify_id", 0);
$can_create = App::$CURRENT->has_permission("schadensfall", "INS");

$schadensfall_arten = SchadensfallArt::load_all();
$status_schadensfall = StatusSchadensfall::load_all();

if (!isset($kunde_id) && !isset($_SESSION["sd-kunde"]) && !isset($kunde_nr)) {

} else if (!isset($kunde_id) && !isset($kunde_nr)) {

    $kunde = $_SESSION["sd-kunde"];

    $kunde_id = $kunde->get_id();
} else if (!isset($kunde_nr)) {

    $kunde = Customer::get($kunde_id);

    $_SESSION["sd-kunde"] = $kunde;
} else {
    $kunde = Customer::get_by_kunde_nr($kunde_nr, App::$CURRENT->MANDANT->get_id());
    $kunde_id = $kunde->get_id();

    if (!isset($kunde_id)) {
        $kunde = Customer::get_by_kunde_nr($kunde_nr_backup, App::$CURRENT->MANDANT->get_id());
        $kunde_id = $kunde->get_id();
        App::$CURRENT->add_error(MSG_NO_RESULTS);

        if (!isset($kunde_id)) {
            unset($kunde);
        }
    }

    if (isset($kunde)) {
        $_SESSION["sd-kunde"] = $kunde;
    } else {
        unset($_SESSION["sd-kunde"]);
    }
}

if (!isset($kunde_nr) && isset($kunde)) {
    $kunde_nr = $kunde->get_kdnr();
}

if (isset($kunde_id)) {
    $stammdaten = Stammdaten::get_by_kunde($kunde_id);
}

if ($mode == "INS") {
    $show_new = false;
    $show_modify = false;
    $show_delete = false;

    $record = new Schadensfall((object) $_POST);
    
    $record->set_stammdaten_id( $stammdaten->get_id());
    $record->set_mandant_id(App::$CURRENT->MANDANT->get_id());

    $id = Schadensfall::insert($record);
    $stammdaten = Stammdaten::get_by_kunde($kunde_id);
}

if ($mode == "UPD") {
    $show_new = false;
    $show_modify = false;
    $show_delete = false;

    $edited_id = param("edited_id");

    $current = Schadensfall::get($modify_id);
    $current->add_informations($_POST);

    Schadensfall::update($current, $current->get_id());
   
}
if ($show_modify) {
    $modify = Schadensfall::get($modify_id);
    $exists = true;
}

if ($show_delete) {
    Schadensfall::delete($modify_id);
}

$count = Schadensfall::count(App::$CURRENT->MANDANT->get_id(), $kunde_nr);
$max_site = $count / $site_count;

$schadensfall = Schadensfall::load_items(App::$CURRENT->MANDANT->get_id(), $kunde_nr, $site * $site_count, $site_count);

if (is_array($schadensfall) && count($schadensfall) > 0) {
    if (!isset($cur_id)) {
        $first = $schadensfall[0];
    } else {
        $first = $schadensfall::get($cur_id);
    }
}

?>

