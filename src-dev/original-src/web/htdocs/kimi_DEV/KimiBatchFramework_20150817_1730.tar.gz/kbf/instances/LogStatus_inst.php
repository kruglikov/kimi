<?php
/* -.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.

* File Name : LogStatus_inst.php

* Purpose :

* Creation Date : 06-08-2015

* Last Modified : Mit 12 Aug 2015 19:50:19 CEST

* Created By : Thomas Greb

* © Greb Consult

_._._._._._._._._._._._._._._._._._._._._.*/

  require ($_SERVER['DOCUMENT_ROOT']."/kbf/config/config.php");
  include_once (Settings::getPublic('root_dir').'config/LogStatus_config.php');

  $logStatus = new LogStatus();

?>
