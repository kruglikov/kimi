<?php
  include ($_SERVER['DOCUMENT_ROOT']."/kbf/config/config.php");
	echo "Teste Datenbank verbindung...";
	include ($rootDir.'config/db.php');
	if (isset($mysqli)) {
		echo "\nDatenbankverbindung erfolgreich: ";
		echo $mysqli->host_info;
	}

?>
