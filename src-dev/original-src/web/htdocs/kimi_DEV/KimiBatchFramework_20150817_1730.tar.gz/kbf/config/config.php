<?php
/* -.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.

* File Name : config.php

* Purpose :

* Creation Date : 23-07-2015

* Last Modified : Son 16 Aug 2015 22:22:58 CEST

* Created By : Thomas Greb

* © Greb Consult

_._._._._._._._._._._._._._._._._._._._._.*/

  //set error message
  error_reporting(E_ALL);
	ini_set("display_errors", true);
  mb_internal_encoding("UTF-8");

  require_once ($_SERVER['DOCUMENT_ROOT'] . "/kbf/classes/Settings.php");


  //general framework settings -- don't change
  Settings::setPublic('kbf_home', "/kbf/");
  Settings::setPublic('root_dir', $_SERVER['DOCUMENT_ROOT'] . Settings::getPublic('kbf_home'));
  Settings::setPublic('http_home', "http://".$_SERVER['HTTP_HOST'].Settings::getPublic('kbf_home'));
  Settings::setPublic('html_home', $_SERVER['DOCUMENT_ROOT'] . DIRECTORY_SEPARATOR);
  

  //db settings
  Settings::setProtected('db_user', 'kimiBatch');
  Settings::setProtected('db_pwd', 'kimiBatch');
  Settings::setProtected('db_host', 'localhost');
  Settings::setProtected('db_name', 'kimiBatch');
  Settings::setProtected('db_port', ini_get('mysqli.default_port')); //mysql default
  Settings::setProtected('db_socket', ini_get('mysqli.default_socket')); //mysql default
  Settings::setProtected('db_charset', 'utf8');


  //ftp settings

  Settings::setProtected('ftp_host', 'gcvirsv03');
  Settings::setProtected('ftp_port', 21);
  Settings::setProtected('ftp_timeout', 90);
  Settings::setProtected('ftp_ssl', true);
  Settings::setProtected('ftp_user', 'ftpuser');
  Settings::setProtected('ftp_pwd', 'ftpuser');
  Settings::setProtected('ftp_passiveMode', false);
  Settings::setProtected('ftp_transferMode', FTP_ASCII); //FTP-Transfermodus: FTP_ASCII oder FTP_BINARY


  //temp directory
  Settings::setPublic('dir_tmp', Settings::getPublic('root_dir') . "tmp/");
  
  //ftp directory locations for file output
  Settings::setPublic('toFtp_test', '/ftp_exchange/to_ftp');

  
  //ftp directory locations for file input
  Settings::setPublic('fromFtp_test', '/ftp_exchange/from_ftp');

  
  //FS directory locations for file input



?>
