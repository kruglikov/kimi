<?php
/* -.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.

* File Name : db_config.php

* Purpose :

* Creation Date : 23-07-2015

* Last Modified : Mit 12 Aug 2015 10:30:47 CEST

* Created By : Thomas Greb

* © Greb Consult

_._._._._._._._._._._._._._._._._._._._._.*/

//connection infos
$dbUser = "kimiBatch";
$password = "kimibatch";
$host = "localhost";
$dbname = "kimiBatch";
$port = ini_get("mysqli.default_port"); //mysql default
$socket = ini_get("mysqli.default_socket"); //mysql default
$charset = "utf8";


//get db connection

$mysqli = new mysqli($host, $dbUser, $password, $dbname, $port, $socket);
$mysqli->set_charset($charset);
if ($mysqli->connect_errno) {
  throw new Exception ("Failed to connect to MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error);
}
?>
